// src/sections/HeroSection.tsx
"use client";

import React from 'react';
import Link from 'next/link';
import Image from 'next/image'; // For Next.js optimized images

const HeroSection: React.FC = () => {
  const skills = [
    { name: 'iOS', img: 'https://hmstech.org/assets/website/images/banner/2.png' }, // Example image for skills
    { name: 'UI/UX', img: 'https://hmstech.org/assets/website/images/banner/4.png' },
    { name: 'Android', img: 'https://hmstech.org/assets/website/images/banner/6.png' },
    { name: 'DevOps', img: 'https://hmstech.org/assets/website/images/banner/14.png' },
  ];

  return (
    <section className="relative flex min-h-screen items-center justify-center pt-32 pb-16 lg:pt-0 lg:pb-0">
      {/* Background shape */}
      {/* You'll need to download and place this image in your public folder */}
      <div className="absolute inset-0 z-0 opacity-10" style={{ backgroundImage: 'url("/assets/h2_shape.png")', backgroundSize: 'cover' }}></div>
      
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 px-4 sm:px-6 max-w-7xl z-10">
        {/* Left Side: Text Content */}
        <div className="flex flex-col justify-center text-center lg:text-left">
          <h1 className="text-5xl lg:text-7xl font-bold leading-tight mb-4 text-text-light">
            Your Trusted<br />
            <span className="text-primary relative inline-block">
              IT Partner
              {/* Optional image under "IT Partner" */}
              {/* <Image
                src="https://hmstech.org/assets/website/images/hero/h2_2.png"
                alt="Highlight"
                width={100} // Adjust based on image actual size
                height={20} // Adjust based on image actual size
                className="absolute bottom-0 left-0 w-full"
              /> */}
            </span>
          </h1>
          <p className="text-lg text-text-gray mb-8 max-w-lg mx-auto lg:mx-0">
            We build powerful web apps, mobile solutions, and digital strategies <br /> to help businesses scale and succeed.
          </p>
          <div className="flex justify-center lg:justify-start">
            <Link
              href="/service"
              className="group flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-lg font-semibold text-background-secondary transition-all duration-300 hover:scale-105"
            >
              Explore Our Services
            </Link>
          </div>

          <div className="mt-16 text-left">
            <p className="text-sm font-semibold uppercase tracking-wider text-text-gray mb-4">OUR CORE SKILLS:</p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              {/* This was a swiper, so I'll simplify to static items for now */}
              {skills.map((skill, index) => (
                <div key={index} className="flex items-center justify-center h-16 w-32 rounded-lg bg-input-bg p-2 shadow-md">
                    {/* If using text-only for skills: */}
                    <span className="text-base font-medium text-text-light">{skill.name}</span>
                    {/* If using images as in the original HTML: */}
                    {/* <Image src={skill.img} alt={skill.name} width={60} height={60} objectFit="contain" /> */}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Contact Form */}
        <div className="flex items-center justify-center lg:justify-end">
          <div className="w-full max-w-md rounded-lg bg-background-secondary p-8 shadow-2xl">
            <h3 className="mb-6 text-2xl font-bold text-text-light">Get a Free Quote</h3>
            <form action="/quote-request" method="POST" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  required
                  className="w-full rounded-md border border-input-border bg-input-bg px-4 py-3 text-text-light placeholder-text-gray focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 outline-none"
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  required
                  className="w-full rounded-md border border-input-border bg-input-bg px-4 py-3 text-text-light placeholder-text-gray focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 outline-none"
                />
              </div>
              <div>
                <select
                  name="service_id"
                  className="w-full appearance-none rounded-md border border-input-border bg-input-bg px-4 py-3 text-text-gray focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 outline-none"
                >
                  <option value="">Select a Service</option>
                  <option value="2">Web Development</option>
                  <option value="4">Mobile App Development</option>
                  <option value="3">WordPress Development</option>
                  <option value="5">Digital Marketing</option>
                  <option value="8">Freelancing Services</option>
                  <option value="9">Website Maintenance</option>
                  <option value="6">Graphic Designing</option>
                  <option value="7">Ads Management (Facebook &amp; Google Ads)</option>
                </select>
                {/* Custom arrow for select could be added with a wrapper div and pseudo-element */}
              </div>
              <div>
                <textarea
                  name="message"
                  placeholder="Write a Message"
                  rows={4}
                  required
                  className="w-full rounded-md border border-input-border bg-input-bg px-4 py-3 text-text-light placeholder-text-gray focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 outline-none resize-none"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full rounded-md bg-primary py-3 text-lg font-semibold text-background-secondary transition-all duration-300 hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;