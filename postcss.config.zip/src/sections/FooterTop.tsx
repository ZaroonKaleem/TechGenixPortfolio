import React from "react";
import Link from "next/link";

const services = [
  { name: "Web Development", href: "/service/2" },
  { name: "Mobile App Development", href: "/service/4" },
  { name: "WordPress Development", href: "/service/3" },
  { name: "Digital Marketing", href: "/service/5" },
  { name: "Freelancing Services", href: "/service/8" },
];

const quickLinks = [
  { name: "About Us", href: "/about" },
  { name: "Services", href: "/service" },
  { name: "Pricing", href: "/pricing" },
  { name: "FAQs", href: "#" },
  { name: "Contact", href: "/contact" },
];

const FooterTop: React.FC = () => {
  return (
    <footer className="pt-24 border-t border-gray-200">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          
          {/* ================= GET IN TOUCH ================= */}
          <div>
            <h4 className="text-lg font-semibold mb-4">
              Get In Touch
            </h4>

            <p className="text-sm text-gray-600 mb-5 leading-relaxed">
              Our team comprises professionals with years of experience delivering cutting-edge IT solutions.
            </p>

            {/* Email */}
            <div className="flex items-center gap-2 text-sm mb-5">
              <span className="text-primary">✉</span>
              <a
                href="mailto:hmstech11@gmail.com"
                className="hover:text-primary transition"
              >
                hmstech11@gmail.com
              </a>
            </div>

            {/* Subscribe form */}
            <form className="flex items-center border border-gray-300 rounded-full overflow-hidden">
              <input
                type="email"
                placeholder="Email Address"
                className="w-full px-4 py-2 text-sm outline-none"
              />
              <button
                type="submit"
                className="px-4 text-primary hover:bg-primary hover:text-white transition"
              >
                ➤
              </button>
            </form>
          </div>

          {/* ================= SERVICES ================= */}
          <div>
            <h4 className="text-lg font-semibold mb-4">
              Services
            </h4>

            <ul className="space-y-3">
              {services.map((service, i) => (
                <li key={i}>
                  <Link
                    href={service.href}
                    className="text-sm text-gray-700 hover:text-primary transition"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* ================= QUICK LINKS ================= */}
          <div>
            <h4 className="text-lg font-semibold mb-4">
              Quick Links
            </h4>

            <ul className="space-y-3">
              {quickLinks.map((link, i) => (
                <li key={i}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-700 hover:text-primary transition"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* ================= OFFICE ================= */}
          <div>
            <h4 className="text-lg font-semibold mb-4">
              Our Office
            </h4>

            <div className="space-y-3 text-sm text-gray-700">
              <div>
                <span className="text-xs text-gray-500">
                  Head Office
                </span>

                <p className="mt-1 leading-relaxed">
                  Main Bakar Mandi Road, Liaquatabad, Near UBL Bank, Faisalabad.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterTop;